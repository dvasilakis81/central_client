export const createParagraph = (text) => ({
    type:'paragraph',
    children:[{text}]
})
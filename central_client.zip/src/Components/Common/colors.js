
export function successBgColor(){
    return 'green'
  }
  export function successFgColor() {
    return 'white'
  }
  
  export function errorBgColor(){
    return 'red';
  }
  
  export function errorFgColor(){
    return 'white';
  }
  
  export function infoBgColor(){
    return '#a67c00';
  }
  
  export function infoFgColor(){
    return 'white';
  }
  